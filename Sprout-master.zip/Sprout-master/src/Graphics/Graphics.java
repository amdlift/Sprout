/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Graphics;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author Exo3
 */
public class Graphics {
    // -------------------------------
    // TreePanel class
    // -------------------------------
    public static class TreePanel extends JPanel {
        private double progress = 0.0;
        
        /**
         * Sets the initial size of the tree panel
         */
        public TreePanel() {
            setPreferredSize(new Dimension(200, 400));
            /*
            String image_link = "/Plant/tree.jpg";
            URL imageURL = getClass().getResource(image_link);
            ImageIcon imageIcon = new ImageIcon(imageURL);
            Image scaledImage = imageIcon.getImage().getScaledInstance(200, 400, Image.SCALE_SMOOTH);
            imageIcon.setImage(scaledImage);
            //treePanel.setIcon(new ImageIcon(imageIcon));
            JLabel imageLabel = new JLabel(imageIcon);
            this.add(imageLabel);
            */
        }
        /**
         * Takes in the current progress of tasks completed and scales the tree to be bigger or smaller based just much is completed
         * @param progress a double var that determines how much should the tree be grown based on how many tasks completed
         */
        public void setProgress(double progress) {
            this.progress = Math.max(0, Math.min(1, progress));
            repaint();
        }
        
        /**
         * Sets the colors and shapes of the tree element before it is painted on screen
         */
        @Override
        protected void paintComponent(java.awt.Graphics g) {
            
            
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int width = getWidth();
            int height = getHeight();

            // background
            g2.setColor(new Color(200, 230, 255));
            g2.fillRect(0, 0, width, height);

            // compute tree size
            int treeHeight = (int) (50 + progress * 300);
            int trunkHeight = treeHeight / 4;
            int canopyHeight = treeHeight - trunkHeight;
            
            
             
            
            // trunk
            g2.setColor(new Color(101, 67, 33));
            int trunkWidth = 20;
            int trunkX = width / 2 - trunkWidth / 2;
            int trunkY = height - trunkHeight;
            g2.fillRect(trunkX, trunkY, trunkWidth, trunkHeight);

            // canopy
            g2.setColor(new Color(34, 139, 34));
            int canopyWidth = (int) (trunkWidth + progress * 100);
            g2.fillOval(width / 2 - canopyWidth / 2, trunkY - canopyHeight + 10, canopyWidth, canopyHeight);
            
            
        }
    }
}
