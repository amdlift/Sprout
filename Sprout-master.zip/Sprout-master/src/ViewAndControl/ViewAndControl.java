/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ViewAndControl;

import Persistance.*;
import Graphics.*;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import javax.swing.DropMode;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.TransferHandler;
import static javax.swing.TransferHandler.MOVE;
import javax.swing.table.DefaultTableModel;
//import sprout.Sprout; //temp

/**
 *
 * @author Exo3
 */
public class ViewAndControl {
    //private Persistance per;
    private Persistance per = new Persistance(this);
    private Persistance.facade fa = per.new facade();
    //Per.SetVAC(this);
    
    private JTable table;
    private Graphics.TreePanel treePanel; 
    private JPanel controlPanel;
    private DefaultTableModel model;
    /*
    public class facade{
        public DefaultTableModel getModel(){
            return model;
        }
    }
    */
    
    /**
     * Initializes the swing utilities to allow use later
     * @param args 
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ViewAndControl().createAndShowGui());
    }
    
    public DefaultTableModel getModel(){
        return model;
    }
    
    /**
     * Uses Swing to create the UI including the TreePanel visual
     * @see TreePanel
     */
    public void createAndShowGui() {
        JFrame frame = new JFrame("Sprout To-Do List");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create table model
        model = new DefaultTableModel(new Object[]{"Done", "Task"}, 0) {
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                return columnIndex == 0 ? Boolean.class : String.class;
            }

            @Override
            public boolean isCellEditable(int row, int column) {
                return true;
            }
        };

        table = new JTable(model);
        table.setFillsViewportHeight(true);
        table.setDragEnabled(true);
        table.setDropMode(DropMode.INSERT_ROWS);
        table.setTransferHandler(new TableRowTransferHandler(table));

        // Table model listener for updates
        model.addTableModelListener(e -> {
            fa.save();
            updateTreeProgress();
        });

        // Tree panel on the right
        treePanel = new Graphics.TreePanel();

        // Control panel with buttons
        controlPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton addButton = new JButton("Add Task");
        JButton removeButton = new JButton("Remove Selected");
        controlPanel.add(addButton);
        controlPanel.add(removeButton);

        addButton.addActionListener(e -> {
            String task = JOptionPane.showInputDialog(null, "Enter a new task:");
            if (task != null && !task.trim().isEmpty()) {
                model.addRow(new Object[]{false, task});
            }
        });

        removeButton.addActionListener(e -> {
            int[] selectedRows = table.getSelectedRows();
            Arrays.sort(selectedRows);
            for (int i = selectedRows.length - 1; i >= 0; i--) {
                model.removeRow(selectedRows[i]);
            }
        });

        // Main panel layout
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(new JScrollPane(table), BorderLayout.CENTER);
        mainPanel.add(treePanel, BorderLayout.EAST);
        mainPanel.add(controlPanel, BorderLayout.SOUTH);

        frame.setContentPane(mainPanel);
        frame.setSize(600, 400);
        frame.setLocationRelativeTo(null);
        frame.setResizable(true);
        frame.setVisible(true);

        fa.load();
        updateTreeProgress();
    }
    // -------------------------------
    // Drag-and-drop row reordering
    // -------------------------------
    private static class TableRowTransferHandler extends TransferHandler {
        private final JTable table;
        private List<Object[]> draggedRows;
        private int[] sourceModelRows;
        private int insertIndex = -1;
        private int rowsInserted = 0;
        private static final DataFlavor FLAVOR = new DataFlavor(List.class, "List of rows");

        public TableRowTransferHandler(JTable table) {
            this.table = table;
        }

        @Override
        protected Transferable createTransferable(JComponent c) {
            int[] selectedViewRows = table.getSelectedRows();
            sourceModelRows = new int[selectedViewRows.length];
            draggedRows = new ArrayList<>();
            DefaultTableModel model = (DefaultTableModel) table.getModel();

            for (int i = 0; i < selectedViewRows.length; i++) {
                int modelRow = table.convertRowIndexToModel(selectedViewRows[i]);
                sourceModelRows[i] = modelRow;
                int colCount = model.getColumnCount();
                Object[] values = new Object[colCount];
                for (int col = 0; col < colCount; col++) {
                    values[col] = model.getValueAt(modelRow, col);
                }
                draggedRows.add(values);
            }

            return new Transferable() {
                @Override public DataFlavor[] getTransferDataFlavors() { return new DataFlavor[]{FLAVOR}; }
                @Override public boolean isDataFlavorSupported(DataFlavor d) { return FLAVOR.equals(d); }
                @Override public Object getTransferData(DataFlavor d) { return draggedRows; }
            };
        }

        @Override
        public int getSourceActions(JComponent c) { return MOVE; }

        @Override
        public boolean canImport(TransferHandler.TransferSupport support) {
            return support.isDrop() && support.isDataFlavorSupported(FLAVOR);
        }

        @SuppressWarnings("unchecked")
        @Override
        public boolean importData(TransferHandler.TransferSupport support) {
            if (!canImport(support)) return false;

            JTable.DropLocation dl = (JTable.DropLocation) support.getDropLocation();
            int viewRow = dl.getRow();
            DefaultTableModel model = (DefaultTableModel) table.getModel();

            int modelInsert;
            if (viewRow < 0 || viewRow >= table.getRowCount()) {
                modelInsert = model.getRowCount();
            } else {
                modelInsert = table.convertRowIndexToModel(viewRow);
            }

            try {
                List<Object[]> rows = (List<Object[]>) support.getTransferable().getTransferData(FLAVOR);
                int insertPos = modelInsert;
                for (Object[] rowData : rows) {
                    model.insertRow(insertPos++, rowData);
                }

                insertIndex = modelInsert;
                rowsInserted = rows.size();

                if (rowsInserted > 0) {
                    int firstView = table.convertRowIndexToView(insertIndex);
                    int lastView = table.convertRowIndexToView(insertIndex + rowsInserted - 1);
                    if (firstView >= 0 && lastView >= firstView) {
                        table.getSelectionModel().setSelectionInterval(firstView, lastView);
                    }
                }

                return true;
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        }

        @Override
        protected void exportDone(JComponent c, Transferable t, int action) {
            if (action == MOVE && sourceModelRows != null) {
                DefaultTableModel model = (DefaultTableModel) table.getModel();
                Integer[] idxs = Arrays.stream(sourceModelRows).boxed().toArray(Integer[]::new);
                Arrays.sort(idxs, Collections.reverseOrder());

                for (int idx : idxs) {
                    int removeIndex = idx;
                    if (insertIndex >= 0 && idx >= insertIndex) {
                        removeIndex = idx + rowsInserted;
                    }
                    if (removeIndex >= 0 && removeIndex < model.getRowCount()) {
                        model.removeRow(removeIndex);
                    } else if (idx >= 0 && idx < model.getRowCount()) {
                        model.removeRow(idx);
                    }
                }
            }
            draggedRows = null;
            sourceModelRows = null;
            insertIndex = -1;
            rowsInserted = 0;
        }
    }
    // -------------------------------
    // Tree progress computation
    // -------------------------------
    private void updateTreeProgress() {
        int total = model.getRowCount();
        int done = 0;
        for (int i = 0; i < total; i++) {
            if (Boolean.TRUE.equals(model.getValueAt(i, 0))) done++;
        }
        double progress = total == 0 ? 0 : (double) done / total;
        treePanel.setProgress(progress);
    }
}
