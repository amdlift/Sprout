/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;
//import Persistance.Persistance.test;
import Persistance.*;
import ViewAndControl.*;
/**
 *
 * @author Exo3
 */
public class Model {
    public static void main(String[] args){
            ViewAndControl VAC = new ViewAndControl();
    }
    // -------------------------------
    // TodoItem class for JSON
    // -------------------------------
    public static class TodoItem {
        
        private boolean done;
        private String task;
        /**
        * class constructor
        */
        public TodoItem(String task, boolean done) {
            this.task = task;
            this.done = done;
        }
        /**
        * Getter function that will return the variable done to determine if a task is completed
         * @return done
        */
        public boolean isDone() { return done; }
        /**
        * A setter function for changing the done variable
        * @param done The bool to be changed
        */
        public void setDone(boolean done) { this.done = done; }
        /**
        * Getter function that will return the variable task 
        * @return task
        */
        public String getTask() { return task; }
        /**
        * A setter function for changing the done variable
        * @param task the string to be changed
        */
        public void setTask(String task) { this.task = task; }
    }
}
