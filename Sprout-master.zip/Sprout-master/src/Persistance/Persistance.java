/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Persistance;

import ViewAndControl.*;
import Model.*;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;
//import sprout.Sprout;

/**
 *
 * @author Exo3
 */
public class Persistance {
    public ViewAndControl VAC;
    
    
    
    private DefaultTableModel model = VAC.getModel();
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private static final Path DATA_FILE = Paths.get(System.getProperty("user.home"), ".sprout_tasks.json");
    
    public void SetVAC(ViewAndControl VC){
            VAC = VC;
        }
    
    public Persistance(ViewAndControl VC){
        VAC = VC;
    }
    
    public class facade{
        public void save(){
            saveTasks();
        }
        public void load(){
            loadTasks();
        }
        
         
    }
    // -------------------------------
    // JSON persistence
    // -------------------------------
    private void saveTasks() {
        model = VAC.getModel();
        List<Model.TodoItem> items = new ArrayList<>();
        for (int i = 0; i < model.getRowCount(); i++) {
            boolean done = Boolean.TRUE.equals(model.getValueAt(i, 0));
            String task = model.getValueAt(i, 1).toString();
            items.add(new Model.TodoItem(task, done));
        }

        try {
            Files.write(DATA_FILE, gson.toJson(items).getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadTasks() {
        model = VAC.getModel();
        if (!Files.exists(DATA_FILE)) return;

        try {
            String json = new String(Files.readAllBytes(DATA_FILE), StandardCharsets.UTF_8);
            Model.TodoItem[] items = gson.fromJson(json, Model.TodoItem[].class);
            for (Model.TodoItem item : items) {
                model.addRow(new Object[]{item.isDone(), item.getTask()});
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}